import os
import re
import subprocess

class Autostart(object):

  def user_autostart_path(self):
    return os.getenv("HOME") + "/.config/autostart/" + "douane.desktop"

  def rclocal_path(self):
    return "/etc/rc.local"

  def is_installed(self):
    return "modprobe douane" in open(self.rclocal_path()).read() and os.path.exists(self.user_autostart_path())

  def install(self):
    if subprocess.call(["gksudo", "/etc/init.d/douane", "installautostart"], stdout=subprocess.DEVNULL) == 0:
      with open(self.user_autostart_path(), "w") as desktop_file:
        desktop_file.write("""[Desktop Entry]
Type=Application
Version=1.0
Name=Douane
GenericName=Douane
Comment=Douane application
Exec=gksudo -- /opt/douane/douaned --debug --pid-file=/opt/douane/pids/douaned.pid
Terminal=false
Categories=GTK;Utility;
StartupNotify=true
                           """)
      return True
    else:
      return False

  def uninstall(self):
    if subprocess.call(["gksudo", "/etc/init.d/douane", "uninstallautostart"], stdout=subprocess.DEVNULL) == 0:
      os.remove(self.user_autostart_path())
      return True
    else:
      return False
