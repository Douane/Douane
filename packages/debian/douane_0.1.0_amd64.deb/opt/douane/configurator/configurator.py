#!/usr/bin/env python3
from gi.repository import Gtk, GLib, Gdk

from douane.gui.mainwindow import MainWindow
MainWindow()

GLib.threads_init()
Gdk.threads_init()
Gdk.threads_enter()
Gtk.main()
Gdk.threads_leave()