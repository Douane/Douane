douane-configurator
===================

Configurator process for the Douane firewall at application layer
